//
//  SceneDelegate.h
//  CAD
//
//  Created by xue on 2020/10/14.
//  Copyright © 2020 ZIV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

