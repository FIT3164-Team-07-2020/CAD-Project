//
//  ViewController.h
//  CAD
//
//  Created by xue on 2020/10/14.
//  Copyright © 2020 ZIV. All rights reserved.
//

#import <UIKit/UIKit.h>
#define SCREEN_BOUNDS [UIScreen mainScreen].bounds

@interface ViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate>
{
    NSArray *pickerArray;
}
@end

