//
//  ViewController.m
//  CAD
//
//  Created by xue on 2020/10/14.
//  Copyright © 2020 ZIV. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *TypicalChestPain;
@property (weak, nonatomic) IBOutlet UITextField *Age;
@property (weak, nonatomic) IBOutlet UITextField *Hypertension;
@property (weak, nonatomic) IBOutlet UITextField *Triglyceride;
@property (strong, nonatomic) IBOutlet UIPickerView *YNPicker;
@property (strong, nonatomic) IBOutlet UIToolbar *toolbar;
- (IBAction)detect:(id)sender;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    pickerArray=[NSArray arrayWithObjects: @"Yes", @"No", nil];
    UIPickerView *YNPicker = [[UIPickerView alloc]init];
    _TypicalChestPain.inputView = YNPicker;
    _TypicalChestPain.inputAccessoryView = _toolbar;
    _TypicalChestPain.delegate =self;
    YNPicker.delegate=self;
    YNPicker.dataSource=self;
    YNPicker.frame = CGRectMake(0, 480, 320, 216);
}

- (UIToolbar *)toolbar{
    if (!_toolbar){
        _toolbar=[[UIToolbar alloc]initWithFrame:(CGRect){0,0,SCREEN_BOUNDS.size.width,40}];        UIBarButtonItem *space = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        UIBarButtonItem *finish = [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(done)];
        [_toolbar setItems:@[space,space,finish]];
    }
    return _toolbar;
}


- (void)done{
    [self resignFirstResponder];
}

- (IBAction)detect:(id)sender {
    [_TypicalChestPain endEditing:YES];}
- (NSInteger)numberOfComponentsInPickerView:(nonnull UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(nonnull UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [pickerArray count];
}
-(NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return [pickerArray objectAtIndex:row];
}
 
-(void)textFieldDidEndEditing:(UITextField *)textField{
    NSInteger row = [_YNPicker selectedRowInComponent:0];
    self.TypicalChestPain.text = [pickerArray objectAtIndex:row];
}

@end
