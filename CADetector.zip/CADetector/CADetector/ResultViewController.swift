//
//  ResultViewController.swift
//  CADetector
//
//  Created by Xinhao Yan on 13/10/20.
//  Copyright © 2020 Xinhao Yan. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {
    
    var age: Int?
    var pain: String?
    var length: Double?
    var htn: String?
    var tg: Double?

    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var resultImage: UIImageView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        predictCAD(age: age!, pain: pain!, length: length!, htn: htn!, tg: tg!)
    }
    
    //predict model based on decision tree with 89.22% AUC
    func predictCAD(age: Int, pain: String, length: Double, htn: String, tg: Double){
        if pain == "Yes" {
            resultLabel.text = "Hidden danger! Further Test!"
            resultImage.tintColor = UIColor.orange
        }
        else {
            if htn == "No" {
                if tg < 94.5 {
                    resultLabel.text = "All good! No hidden danger!"
                    resultImage.image = UIImage.init(systemName: "face.smiling")
                    resultImage.tintColor = UIColor.green
                }
                else {
                    if age < 46 {
                        resultLabel.text = "All good! No hidden danger!"
                        resultImage.image = UIImage.init(systemName: "face.smiling")
                        resultImage.tintColor = UIColor.green
                    }
                    else {
                        if length < 161.5 {
                            resultLabel.text = "All good! No hidden danger!"
                            resultImage.image = UIImage.init(systemName: "face.smiling")
                            resultImage.tintColor = UIColor.green
                        }
                        else {
                            resultLabel.text = "Hidden danger! Further Test!"
                            resultImage.tintColor = UIColor.orange
                        }
                    }
                }
            }
            else {
                if tg < 171.5 {
                    if age <= 53 {
                        resultLabel.text = "All good! No hidden danger!"
                        resultImage.image = UIImage.init(systemName: "face.smiling")
                        resultImage.tintColor = UIColor.green
                    }
                    else {
                        resultLabel.text = "Hidden danger! Further Test!"
                        resultImage.tintColor = UIColor.orange
                    }
                }
                else {
                    resultLabel.text = "Hidden danger! Further Test!"
                    resultImage.tintColor = UIColor.orange
                }
            }
            
        }
    }
    


}

