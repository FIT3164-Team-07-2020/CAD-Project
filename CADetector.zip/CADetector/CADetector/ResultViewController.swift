//
//  ResultViewController.swift
//  CADetector
//
//  Created by Xinhao Yan on 13/10/20.
//  Copyright © 2020 Xinhao Yan. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {
    
    var age: Int?
    var pain: String?
    var htn: String?
    var tg: Double?

    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var resultImage: UIImageView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        predictCAD(age: age!, pain: pain!, htn: htn!, tg: tg!)
    }
    
    func predictCAD(age: Int, pain: String, htn: String, tg: Double){
        if pain == "Yes" {
            resultLabel.text = "Hidden danger! Further Test!"
            resultImage.tintColor = UIColor.orange
        }
        else {
            if htn == "No" {
                resultLabel.text = "All good! No hidden danger!"
                resultImage.image = UIImage.init(systemName: "face.smiling")
                resultImage.tintColor = UIColor.green
            }
            else {
                if tg >= 171.5 {
                    resultLabel.text = "Hidden danger! Further Test!"
                    resultImage.tintColor = UIColor.orange
                }
                else {
                    if age <= 53 {
                        resultLabel.text = "All good! No hidden danger!"
                        resultImage.image = UIImage.init(systemName: "face.smiling")
                        resultImage.tintColor = UIColor.green
                    }
                    else {
                        resultLabel.text = "Hidden danger! Further Test!"
                        resultImage.tintColor = UIColor.orange
                    }
                }
            }
        }
    }


}
