//
//  ViewController.swift
//  CADetector
//
//  Created by Xinhao Yan on 7/9/20.
//  Copyright © 2020 Xinhao Yan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var painLabel: UITextField!
    
    @IBOutlet weak var ageLabel: UITextField!
    
    @IBOutlet weak var lengthLabel: UITextField!
    
    @IBOutlet weak var htnLabel: UITextField!
    
    @IBOutlet weak var tgLabel: UITextField!
    
    @IBAction func tipsBtn(_ sender: UIBarButtonItem) {
        let titleString = "Tips"
        let messageString = "This is a simple application to detect heart diseases with 89.2% AUC. This app is just for convenient usage that all the features are really easy to get. We have our best model on the web page with much more details that need to be filled in. If you want to have the best guess of heart diseases, you can go and check our website out."
        displayMessage(title: titleString, msg: messageString)
    }
    
    
    
    
    var age: Int?
    var pain: String?
    var length: Double?
    var htn: String?
    var tg: Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        painLabel.delegate = self
        ageLabel.delegate = self
        lengthLabel.delegate = self
        htnLabel.delegate = self
        tgLabel.delegate = self
    }
    
    //keyboard 'return' button design
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == painLabel {
            painLabel.resignFirstResponder()
            ageLabel.becomeFirstResponder()
            return true
        }
        
        if textField == ageLabel {
            ageLabel.resignFirstResponder()
            lengthLabel.becomeFirstResponder()
            return true
        }
        
        if textField == lengthLabel {
            lengthLabel.resignFirstResponder()
            htnLabel.becomeFirstResponder()
        }
        
        if textField == htnLabel {
            htnLabel.resignFirstResponder()
            tgLabel.becomeFirstResponder()
            return true
        }
        
        if textField == tgLabel {
            tgLabel.resignFirstResponder()
            performSegue(withIdentifier: "ResultSegue", sender: self)
            return true
        }
        
        return true
        
    }
    
    
    func displayMessage(title:String,msg:String){
        let alertController = UIAlertController(title: title, message: msg, preferredStyle: UIAlertController.Style.alert)
    alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "ResultSegue" {
            
            age = Int(ageLabel.text!)
            pain = painLabel.text
            length = Double(lengthLabel.text!)
            htn = htnLabel.text
            tg = Double(tgLabel.text!)
            
            //if miss values, warning.
            if age == nil || pain == nil || length == nil || htn == nil || tg == nil {
                displayMessage(title: "Warning", msg: "Please fill in all the variables with right format.")
            }
            
            if (pain == "Yes" || pain == "No") && (htn == "Yes" || htn == "No") {
                let controller = segue.destination as! ResultViewController
                
                controller.age = age
                controller.pain = pain
                controller.length = length
                controller.htn = htn
                controller.tg = tg
            }
            
            //if values are in wrong format, warning.
            else {
                displayMessage(title: "Warning", msg: "Please fill in all the variables with right format.")
            }
            
            
        }
    }
    

}

