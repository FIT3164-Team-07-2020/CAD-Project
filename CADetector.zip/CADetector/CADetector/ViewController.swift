//
//  ViewController.swift
//  CADetector
//
//  Created by Xinhao Yan on 7/9/20.
//  Copyright © 2020 Xinhao Yan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var painLabel: UITextField!
    
    @IBOutlet weak var ageLabel: UITextField!
    
    @IBOutlet weak var lengthLabel: UITextField!
    
    @IBOutlet weak var htnLabel: UITextField!
    
    @IBOutlet weak var tgLabel: UITextField!
    
    @IBAction func tipsBtn(_ sender: UIBarButtonItem) {
        let titleString = "Tips"
        let messageString = "This is a simple application to detect heart diseases. This app is just for convenient usage that all the features are really easy to get. We have our best model on the web page with much more details that need to be filled in. If you want to have the best guess of heart diseases, you can go and check our website as follow: \n\nhttps://monash-fit3164-team07-2020.shinyapps.io/CAD_Predictor"
        displayMessage(title: titleString, msg: messageString)
    }
    
    
    
    
    var age: Int?
    var pain: String?
    var length: Double?
    var htn: String?
    var tg: Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        painLabel.delegate = self
        ageLabel.delegate = self
        lengthLabel.delegate = self
        htnLabel.delegate = self
        tgLabel.delegate = self
    }
    
    //keyboard 'return' button design
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == painLabel {
            painLabel.resignFirstResponder()
            ageLabel.becomeFirstResponder()
            return true
        }
        
        if textField == ageLabel {
            ageLabel.resignFirstResponder()
            lengthLabel.becomeFirstResponder()
            return true
        }
        
        if textField == lengthLabel {
            lengthLabel.resignFirstResponder()
            htnLabel.becomeFirstResponder()
        }
        
        if textField == htnLabel {
            htnLabel.resignFirstResponder()
            tgLabel.becomeFirstResponder()
            return true
        }
        
        if textField == tgLabel {
            tgLabel.resignFirstResponder()
            performSegue(withIdentifier: "ResultSegue", sender: self)
            return true
        }
        
        return true
        
    }
    
    
    func displayMessage(title:String,msg:String){
        let alertController = UIAlertController(title: title, message: msg, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "ResultSegue" {
            
            //Bug fixing: Warning when face the wrong input values and types
            //if miss values, warning. if wrong type of values, warning.
            if Int(ageLabel.text!) == nil || painLabel.text == nil || Double(lengthLabel.text!) == nil || htnLabel.text == nil || Double(tgLabel.text!) == nil {
                displayMessage(title: "Warning", msg: "Please fill in all the variables with right format.")
                return
            }
            
            //check whether the strings are filled in Yes/No
            if (painLabel.text == "Yes" || painLabel.text == "No") && (htnLabel.text == "Yes" || htnLabel.text == "No") {
                //check the numeric values to be positive
                if (Int(ageLabel.text!)! >= 0) && (Double(tgLabel.text!)! >= 0.0) && (Double(lengthLabel.text!)! >= 0.0){
                    
                    let controller = segue.destination as! ResultViewController
                    
                    controller.age = Int(ageLabel.text!)
                    controller.pain = painLabel.text
                    controller.length = Double(lengthLabel.text!)
                    controller.htn = htnLabel.text
                    controller.tg = Double(tgLabel.text!)
                }
                //if age and tg are negative values, warning
                else {
                    displayMessage(title: "Warning", msg: "Please fill in positive values in Age, Height and Triglyceride.")
                    return
                }
            }
            
            //if values are in wrong format, warning.
            else {
                displayMessage(title: "Warning", msg: "Please fill in Yes or No in Typical Chest Pain and Hypertension.")
                return
            }
            
            
        }
    }
    

}

